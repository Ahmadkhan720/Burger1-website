<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🍔 BurgerHub - All About Burgers (2025)</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        :root {
            --primary: #ff6b00;
            --primary-dark: #e05a00;
            --secondary: #333;
            --light: #f8f8f8;
            --dark: #222;
            --text: #444;
            --shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }

        body {
            background: var(--light);
            color: var(--text);
            overflow-x: hidden;
            line-height: 1.6;
        }

        h1, h2, h3, h4 {
            color: var(--secondary);
            line-height: 1.2;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        section {
            padding: 80px 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 60px;
            position: relative;
        }

        .section-title h2 {
            font-size: 2.5rem;
            display: inline-block;
        }

        .section-title h2 span {
            color: var(--primary);
        }

        .section-title h2::after {
            content: '';
            position: absolute;
            width: 80px;
            height: 3px;
            background: var(--primary);
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
        }

        .btn {
            display: inline-block;
            padding: 12px 30px;
            border-radius: var(--radius);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            text-align: center;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(255, 107, 0, 0.2);
        }

        /* ===== NAVIGATION ===== */
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 5%;
            background: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            z-index: 1000;
        }

        .logo a {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--secondary);
            text-decoration: none;
        }

        .logo span {
            color: var(--primary);
        }

        .nav-links {
            display: flex;
            list-style: none;
        }

        .nav-links li {
            margin-left: 30px;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--secondary);
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        .nav-links a.active {
            color: var(--primary);
        }

        .hamburger {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* ===== HERO SECTION ===== */
        .about-hero {
            height: 60vh;
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80') no-repeat center/cover;
            display: flex;
            align-items: center;
            text-align: center;
            color: white;
            padding-top: 80px;
        }

        .about-hero-content {
            max-width: 800px;
            margin: 0 auto;
        }

        .about-hero h1 {
            font-size: 3.5rem;
            margin-bottom: 20px;
            color: white;
        }

        .about-hero p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto 30px;
        }

        /* ===== BURGER HISTORY SECTION ===== */
        .burger-history {
            background: white;
        }

        .history-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 50px;
            align-items: center;
        }

        .history-text h3 {
            font-size: 1.8rem;
            margin-bottom: 20px;
        }

        .history-text h3 span {
            color: var(--primary);
        }

        .history-text p {
            margin-bottom: 15px;
        }

        .history-image {
            position: relative;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .history-image img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.5s ease;
        }

        .history-image:hover img {
            transform: scale(1.05);
        }

        .history-image::before {
            content: '1885 - First Hamburger';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 10px;
            text-align: center;
            font-weight: 500;
        }

        /* ===== BURGER TYPES SECTION ===== */
        .burger-types {
            background: var(--light);
        }

        .types-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .type-card {
            background: white;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
        }

        .type-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .type-image {
            height: 200px;
            overflow: hidden;
        }

        .type-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .type-card:hover .type-image img {
            transform: scale(1.1);
        }

        .type-content {
            padding: 20px;
        }

        .type-content h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--secondary);
        }

        .type-content p {
            margin-bottom: 15px;
            color: var(--text);
        }

        .type-origin {
            display: flex;
            align-items: center;
            color: var(--primary);
            font-weight: 500;
            margin-top: 15px;
        }

        .type-origin i {
            margin-right: 8px;
        }

        /* ===== FUN FACTS SECTION ===== */
        .fun-facts {
            background: white;
        }

        .facts-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }

        .fact-card {
            background: var(--light);
            padding: 30px;
            border-radius: var(--radius);
            text-align: center;
            transition: all 0.3s ease;
        }

        .fact-card:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-5px);
        }

        .fact-card:hover h3,
        .fact-card:hover .fact-icon {
            color: white;
        }

        .fact-icon {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }

        .fact-card h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
            color: var(--secondary);
            transition: all 0.3s ease;
        }

        /* ===== BURGER CULTURE SECTION ===== */
        .burger-culture {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://images.unsplash.com/photo-1604135307399-86c6ce0aba8e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80') no-repeat center/cover;
            color: white;
            text-align: center;
        }

        .culture-content {
            max-width: 800px;
            margin: 0 auto;
        }

        .culture-content h2 {
            color: white;
        }

        .culture-content h2::after {
            background: var(--primary);
        }

        .culture-content p {
            margin-bottom: 20px;
            font-size: 1.1rem;
        }

        /* ===== FOOTER ===== */
        footer {
            background: var(--secondary);
            color: white;
            padding: 60px 0 20px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .footer-logo {
            margin-bottom: 20px;
        }

        .footer-logo a {
            font-size: 1.8rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }

        .footer-logo span {
            color: var(--primary);
        }

        .footer-about p {
            margin-bottom: 20px;
            opacity: 0.8;
        }

        .footer-links h3, .footer-contact h3 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-links h3::after, .footer-contact h3::after {
            content: '';
            position: absolute;
            width: 50px;
            height: 2px;
            background: var(--primary);
            bottom: 0;
            left: 0;
        }

        .footer-links ul {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: white;
            opacity: 0.8;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-links a:hover {
            opacity: 1;
            color: var(--primary);
            padding-left: 5px;
        }

        .contact-info {
            margin-bottom: 20px;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .contact-item i {
            color: var(--primary);
            margin-right: 10px;
            margin-top: 5px;
        }

        .social-links {
            display: flex;
            gap: 15px;
        }

        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            color: white;
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            background: var(--primary);
            transform: translateY(-3px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-bottom p {
            opacity: 0.7;
            font-size: 0.9rem;
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 992px) {
            .about-hero h1 {
                font-size: 3rem;
            }
        }

        @media (max-width: 768px) {
            .nav-links {
                position: fixed;
                top: 80px;
                left: -100%;
                width: 100%;
                height: calc(100vh - 80px);
                background: white;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                transition: all 0.5s ease;
            }

            .nav-links.active {
                left: 0;
            }

            .nav-links li {
                margin: 15px 0;
            }

            .hamburger {
                display: block;
            }

            .about-hero {
                height: 50vh;
                padding-top: 70px;
            }

            .about-hero h1 {
                font-size: 2.5rem;
            }

            .section-title h2 {
                font-size: 2rem;
            }
        }

        @media (max-width: 576px) {
            .about-hero h1 {
                font-size: 2rem;
            }

            .about-hero p {
                font-size: 1rem;
            }

            .section-title h2 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <!-- ===== NAVIGATION ===== -->
    <nav>
        <div class="logo">
           <a href="landingpage.php">Burger<span>Hub</span></a>
        </div>
        <ul class="nav-links">
            <li><a href="landingpage.php">Home</a></li>
            <li><a href="order.php">Order Now</a></li>
            <!-- <li><a href="aboutburgers.html" class="active">About Burgers</a></li> -->
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="contactus.php">Contact</a></li>
        </ul>
        <div class="hamburger">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <!-- ===== HERO SECTION ===== -->
    <section class="about-hero">
        <div class="about-hero-content">
            <h1>The Wonderful World <span>of Burgers</span></h1>
            <p>From humble beginnings to global phenomenon, explore the rich history and diverse varieties of this iconic dish</p>
            <a href="#history" class="btn btn-primary">Explore Burger History</a>
        </div>
    </section>

    <!-- ===== BURGER HISTORY SECTION ===== -->
    <section class="burger-history" id="history">
        <div class="container">
            <div class="section-title">
                <h2>The <span>History</span> of Burgers</h2>
            </div>
            <div class="history-content">
                <div class="history-text">
                    <h3>From <span>Humble Beginnings</span> to Global Icon</h3>
                    <p>The hamburger as we know it today has disputed origins, with several American towns claiming to be its birthplace. The most widely accepted story traces it back to 1885 when brothers Charles and Frank Menches ran out of pork sausages at their stand at the Erie County Fair in Hamburg, New York, and substituted beef.</p>
                    <p>By the early 20th century, the hamburger was already becoming a symbol of American fast food culture. The White Castle chain, founded in 1921, helped popularize the burger by emphasizing cleanliness and standardization at a time when ground beef had a questionable reputation.</p>
                    <p>The post-World War II era saw an explosion of burger popularity with the rise of McDonald's and other fast food chains. Today, the hamburger has evolved into countless regional and gourmet variations while remaining a staple of global cuisine.</p>
                </div>
                <div class="history-image">
                    <img src="https://images.unsplash.com/photo-1565299585323-38d6b0865b47?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="First Hamburger">
                </div>
            </div>
        </div>
    </section>

    <!-- ===== BURGER TYPES SECTION ===== -->
    <section class="burger-types">
        <div class="container">
            <div class="section-title">
                <h2>Global Burger <span>Varieties</span></h2>
            </div>
            <div class="types-grid">
                <!-- American Classic -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="American Classic Burger">
                    </div>
                    <div class="type-content">
                        <h3>American Classic</h3>
                        <p>The quintessential burger with a beef patty, American cheese, lettuce, tomato, onion, pickles, and special sauce on a sesame seed bun.</p>
                        <div class="type-origin">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>United States</span>
                        </div>
                    </div>
                </div>

                <!-- Jucy Lucy -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1553979459-d2229ba7433b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Jucy Lucy Burger">
                    </div>
                    <div class="type-content">
                        <h3>Jucy Lucy</h3>
                        <p>A Minneapolis specialty featuring cheese stuffed inside the patty that melts when cooked, creating a delicious molten center.</p>
                        <div class="type-origin">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Minnesota, USA</span>
                        </div>
                    </div>
                </div>

                <!-- Ramen Burger -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1549611016-3a70d82b5040?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Ramen Burger">
                    </div>
                    <div class="type-content">
                        <h3>Ramen Burger</h3>
                        <p>An innovative fusion burger that uses compressed ramen noodles as the "bun" with a beef patty and Asian-inspired toppings.</p>
                        <div class="type-origin">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>New York, USA</span>
                        </div>
                    </div>
                </div>

                <!-- Rice Burger -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Rice Burger">
                    </div>
                    <div class="type-content">
                        <h3>Rice Burger</h3>
                        <p>A Japanese variation where the bun is replaced with compressed rice cakes, often filled with teriyaki chicken or beef.</p>
                        <div class="type-origin">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Japan</span>
                        </div>
                    </div>
                </div>

                <!-- Veggie Burger -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1596662951482-0c4ba74a6df6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Veggie Burger">
                    </div>
                    <div class="type-content">
                        <h3>Veggie Burger</h3>
                        <p>A plant-based patty made from ingredients like beans, lentils, quinoa or mushrooms, catering to vegetarian and vegan diets.</p>
                        <div class="type-origin">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Global</span>
                        </div>
                    </div>
                </div>

                <!-- Butter Burger -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1585238341267-1cfec2046a55?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="Butter Burger">
                    </div>
                    <div class="type-content">
                        <h3>Butter Burger</h3>
                        <p>A Wisconsin specialty where the patty is cooked in butter and often topped with more butter, creating an exceptionally rich flavor.</p>
                        <div class="type-origin">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Wisconsin, USA</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== FUN FACTS SECTION ===== -->
    <section class="fun-facts">
        <div class="container">
            <div class="section-title">
                <h2>Burger <span>Fun Facts</span></h2>
            </div>
            <div class="facts-container">
                <div class="fact-card">
                    <div class="fact-icon">
                        <i class="fas fa-hamburger"></i>
                    </div>
                    <h3>50 Billion</h3>
                    <p>Burgers consumed annually in the United States alone</p>
                </div>
                <div class="fact-card">
                    <div class="fact-icon">
                        <i class="fas fa-utensils"></i>
                    </div>
                    <h3>62%</h3>
                    <p>Of all sandwiches sold worldwide are hamburgers</p>
                </div>
                <div class="fact-card">
                    <div class="fact-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h3>1935</h3>
                    <p>Year the first drive-thru hamburger stand opened</p>
                </div>
                <div class="fact-card">
                    <div class="fact-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <h3>10,000 lbs</h3>
                    <p>Weight of the world's largest hamburger ever made</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== BURGER CULTURE SECTION ===== -->
    <section class="burger-culture">
        <div class="container">
            <div class="culture-content">
                <div class="section-title">
                    <h2>Burger <span>Culture</span></h2>
                </div>
                <p>The hamburger has transcended its humble origins to become a cultural icon, representing everything from American capitalism to globalized food culture. It's celebrated in films, music, and art, and has spawned competitive eating contests worldwide.</p>
                <p>Today's burger culture embraces both fast-food simplicity and gourmet sophistication. Food trucks, gastropubs, and high-end restaurants all put their unique spin on this versatile dish, while annual burger festivals draw thousands of enthusiasts.</p>
                <p>At BurgerHub, we honor this rich tradition while innovating for the future. Our burgers represent the perfect marriage of classic techniques and modern flavors, crafted with respect for the burger's storied history.</p>
                <a href="order.php" class="btn btn-primary">Try Our Burgers</a>
            </div>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <div class="footer-logo">
                        <a href="index.html">Burger<span>Hub</span></a>
                    </div>
                    <p>Celebrating burger culture since 2025. Our mission is to serve the most delicious burgers while honoring the rich history of this iconic dish.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-yelp"></i></a>
                    </div>
                </div>

                <div class="footer-links">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="landingpage.php">Home</a></li>
                        <li><a href="order.php">Order Online</a></li>
                        <li><a href="aboutburgers.php">About Burgers</a></li>
                        <li><a href="aboutus.phpl">About Us</a></li>
                        <li><a href="contactus.php">Contact</a></li>
                    </ul>
                </div>

                <div class="footer-contact">
                    <h3>Contact Us</h3>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <p>123 Burger Street, Food City, FC 12345</p>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone-alt"></i>
                            <p>(555) 123-4567</p>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <p>info@burgerhub.com</p>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-clock"></i>
                            <p>Open Daily: 11AM - 10PM</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 BurgerHub. All rights reserved. | Designed and Developed by <strong>Muhammad Ahmad Khan</strong></p>
            </div>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile Menu Toggle
        const hamburger = document.querySelector('.hamburger');
        const navLinks = document.querySelector('.nav-links');
        
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            hamburger.innerHTML = navLinks.classList.contains('active') ? 
                '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                if (navLinks.classList.contains('active')) {
                    navLinks.classList.remove('active');
                    hamburger.innerHTML = '<i class="fas fa-bars"></i>';
                }
            });
        });
    </script>
</body>
</html>