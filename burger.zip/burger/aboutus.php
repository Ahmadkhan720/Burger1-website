<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🍔 BurgerHub - About Us (2025)</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        :root {
            --primary: #ff6b00;
            --primary-dark: #e05a00;
            --secondary: #333;
            --light: #f8f8f8;
            --dark: #222;
            --text: #444;
            --shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }

        body {
            background: var(--light);
            color: var(--text);
            overflow-x: hidden;
            line-height: 1.6;
        }

        h1, h2, h3, h4 {
            color: var(--secondary);
            line-height: 1.2;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        section {
            padding: 80px 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 60px;
            position: relative;
        }

        .section-title h2 {
            font-size: 2.5rem;
            display: inline-block;
        }

        .section-title h2 span {
            color: var(--primary);
        }

        .section-title h2::after {
            content: '';
            position: absolute;
            width: 80px;
            height: 3px;
            background: var(--primary);
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
        }

        .btn {
            display: inline-block;
            padding: 12px 30px;
            border-radius: var(--radius);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            text-align: center;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(255, 107, 0, 0.2);
        }

        /* ===== NAVIGATION ===== */
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 5%;
            background: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            z-index: 1000;
        }

        .logo a {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--secondary);
            text-decoration: none;
        }

        .logo span {
            color: var(--primary);
        }

        .nav-links {
            display: flex;
            list-style: none;
        }

        .nav-links li {
            margin-left: 30px;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--secondary);
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        .nav-links a.active {
            color: var(--primary);
        }

        .hamburger {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* ===== HERO SECTION ===== */
        .about-hero {
            height: 60vh;
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80') no-repeat center/cover;
            display: flex;
            align-items: center;
            text-align: center;
            color: white;
            padding-top: 80px;
        }

        .about-hero-content {
            max-width: 800px;
            margin: 0 auto;
        }

        .about-hero h1 {
            font-size: 3.5rem;
            margin-bottom: 20px;
            color: white;
        }

        .about-hero p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto 30px;
        }

        /* ===== OUR STORY SECTION ===== */
        .our-story {
            background: white;
        }

        .story-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 50px;
            align-items: center;
        }

        .story-text h3 {
            font-size: 1.8rem;
            margin-bottom: 20px;
        }

        .story-text h3 span {
            color: var(--primary);
        }

        .story-text p {
            margin-bottom: 15px;
        }

        .story-image {
            position: relative;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .story-image img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.5s ease;
        }

        .story-image:hover img {
            transform: scale(1.05);
        }

        /* ===== OUR TEAM SECTION ===== */
        .our-team {
            background: var(--light);
        }

        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }

        .team-member {
            background: white;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            text-align: center;
        }

        .team-member:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .member-image {
            height: 300px;
            overflow: hidden;
        }

        .member-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .team-member:hover .member-image img {
            transform: scale(1.1);
        }

        .member-info {
            padding: 20px;
        }

        .member-info h3 {
            font-size: 1.3rem;
            margin-bottom: 5px;
        }

        .member-info p {
            color: var(--primary);
            font-weight: 500;
            margin-bottom: 15px;
        }

        .member-social {
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .member-social a {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: var(--light);
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .member-social a:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-3px);
        }

        /* ===== OUR VALUES SECTION ===== */
        .our-values {
            background: white;
        }

        .values-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .value-card {
            text-align: center;
            padding: 30px;
            border-radius: var(--radius);
            transition: all 0.3s ease;
        }

        .value-card:hover {
            background: var(--light);
            transform: translateY(-5px);
        }

        .value-icon {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 20px;
        }

        .value-card h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        /* ===== CTA SECTION ===== */
        .cta-section {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://images.unsplash.com/photo-1604135307399-86c6ce0aba8e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80') no-repeat center/cover;
            color: white;
            text-align: center;
            padding: 100px 0;
        }

        .cta-section h2 {
            color: white;
            margin-bottom: 20px;
        }

        .cta-section h2 span {
            color: var(--primary);
        }

        .cta-section p {
            max-width: 700px;
            margin: 0 auto 30px;
            font-size: 1.1rem;
        }

        /* ===== FOOTER ===== */
        footer {
            background: var(--secondary);
            color: white;
            padding: 60px 0 20px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .footer-logo {
            margin-bottom: 20px;
        }

        .footer-logo a {
            font-size: 1.8rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }

        .footer-logo span {
            color: var(--primary);
        }

        .footer-about p {
            margin-bottom: 20px;
            opacity: 0.8;
        }

        .footer-links h3, .footer-contact h3 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-links h3::after, .footer-contact h3::after {
            content: '';
            position: absolute;
            width: 50px;
            height: 2px;
            background: var(--primary);
            bottom: 0;
            left: 0;
        }

        .footer-links ul {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: white;
            opacity: 0.8;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-links a:hover {
            opacity: 1;
            color: var(--primary);
            padding-left: 5px;
        }

        .contact-info {
            margin-bottom: 20px;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .contact-item i {
            color: var(--primary);
            margin-right: 10px;
            margin-top: 5px;
        }

        .social-links {
            display: flex;
            gap: 15px;
        }

        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            color: white;
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            background: var(--primary);
            transform: translateY(-3px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-bottom p {
            opacity: 0.7;
            font-size: 0.9rem;
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 992px) {
            .about-hero h1 {
                font-size: 3rem;
            }
        }

        @media (max-width: 768px) {
            .nav-links {
                position: fixed;
                top: 80px;
                left: -100%;
                width: 100%;
                height: calc(100vh - 80px);
                background: white;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                transition: all 0.5s ease;
            }

            .nav-links.active {
                left: 0;
            }

            .nav-links li {
                margin: 15px 0;
            }

            .hamburger {
                display: block;
            }

            .about-hero {
                height: 50vh;
                padding-top: 70px;
            }

            .about-hero h1 {
                font-size: 2.5rem;
            }

            .section-title h2 {
                font-size: 2rem;
            }
        }

        @media (max-width: 576px) {
            .about-hero h1 {
                font-size: 2rem;
            }

            .about-hero p {
                font-size: 1rem;
            }

            .section-title h2 {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <!-- ===== NAVIGATION ===== -->
    <nav>
        <div class="logo">
       <a href="landingpage.php">Burger<span>Hub</span></a>
        </div>
        <ul class="nav-links">
            <li><a href="landingpage.php">Home</a></li>
                        <li><a href="order.php">Order Online</a></li>
                        <li><a href="contactus.php">Contact</a></li>
        </ul>
        <div class="hamburger">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <!-- ===== HERO SECTION ===== -->
    <section class="about-hero">
        <div class="about-hero-content">
            <h1>Our <span>Story</span></h1>
            <p>From a small food truck to the city's favorite burger destination, discover the passion behind BurgerHub</p>
            <a href="#story" class="btn btn-primary">Learn More</a>
        </div>
    </section>

    <!-- ===== OUR STORY SECTION ===== -->
    <section class="our-story" id="story">
        <div class="container">
            <div class="section-title">
                <h2>How It All <span>Began</span></h2>
            </div>
            <div class="story-content">
                <div class="story-text">
                    <h3>From <span>Dream</span> to Reality</h3>
                    <p>BurgerHub was born in 2025 when founder Michael Rodriguez transformed his lifelong passion for burgers into a modest food truck operation. What started as a single truck serving downtown office workers quickly gained a cult following for its perfectly seasoned patties and artisanal buns.</p>
                    <p>Within a year, the overwhelming demand led to the opening of our first brick-and-mortar location. Today, we operate five restaurants across the city, but we've never lost sight of our food truck roots - every burger is still made with the same care and attention as when we served our very first customer.</p>
                    <p>Our mission remains simple: to craft the juiciest, most flavorful burgers using only the finest ingredients, served with genuine hospitality that makes every guest feel like family.</p>
                </div>
                <div class="story-image">
                    <img src="https://images.unsplash.com/photo-1512152272829-e3139592d56f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" alt="BurgerHub Food Truck">
                </div>
            </div>
        </div>
    </section>

    <!-- ===== OUR TEAM SECTION ===== -->
    <section class="our-team">
        <div class="container">
            <div class="section-title">
                <h2>Meet Our <span>Team</span></h2>
            </div>
            <div class="team-grid">
                <div class="team-member">
                    <div class="member-image">
                        <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Michael Rodriguez">
                    </div>
                    <div class="member-info">
                        <h3>Michael Rodriguez</h3>
                        <p>Founder & Head Chef</p>
                        <div class="member-social">
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>

                <div class="team-member">
                    <div class="member-image">
                        <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Sarah Chen">
                    </div>
                    <div class="member-info">
                        <h3>Sarah Chen</h3>
                        <p>General Manager</p>
                        <div class="member-social">
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>

                <div class="team-member">
                    <div class="member-image">
                        <img src="https://randomuser.me/api/portraits/men/75.jpg" alt="David Wilson">
                    </div>
                    <div class="member-info">
                        <h3>David Wilson</h3>
                        <p>Executive Chef</p>
                        <div class="member-social">
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>

                <div class="team-member">
                    <div class="member-image">
                        <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Emily Johnson">
                    </div>
                    <div class="member-info">
                        <h3>Emily Johnson</h3>
                        <p>Marketing Director</p>
                        <div class="member-social">
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== OUR VALUES SECTION ===== -->
    <section class="our-values">
        <div class="container">
            <div class="section-title">
                <h2>Our Core <span>Values</span></h2>
            </div>
            <div class="values-grid">
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h3>Quality</h3>
                    <p>We source only the finest ingredients and never compromise on quality, from our grass-fed beef to our locally baked buns.</p>
                </div>

                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-leaf"></i>
                    </div>
                    <h3>Sustainability</h3>
                    <p>We're committed to environmentally responsible practices, from eco-friendly packaging to supporting local farmers.</p>
                </div>

                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>Community</h3>
                    <p>We believe in giving back to the neighborhoods we serve through charity events and youth programs.</p>
                </div>

                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-lightbulb"></i>
                    </div>
                    <h3>Innovation</h3>
                    <p>While honoring tradition, we constantly experiment with new flavors and techniques to surprise and delight our customers.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== CTA SECTION ===== -->
    <section class="cta-section">
        <div class="container">
            <h2>Ready to Taste <span>the Difference?</span></h2>
            <p>Experience the BurgerHub magic for yourself. Visit us today or order online for delivery!</p>
            <a href="order.php" class="btn btn-primary">Order Now</a>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <div class="footer-logo">
                        <a href="index.html">Burger<span>Hub</span></a>
                    </div>
                    <p>Celebrating burger excellence since 2025. Crafted with passion, served with pride.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-yelp"></i></a>
                    </div>
                </div>

                <div class="footer-links">
                    <h3>Quick Links</h3>
                    <ul>
                      <li><a href="landingpage.php">Home</a></li>
                        <li><a href="order.php">Order Online</a></li>
                        <li><a href="aboutburgers.php">About Burgers</a></li>
                        <li><a href="aboutus.phpl">About Us</a></li>
                        <li><a href="contactus.php">Contact</a></li>
                    </ul>
                </div>

                <div class="footer-contact">
                    <h3>Contact Us</h3>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <p>123 Burger Street, Food City, FC 12345</p>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone-alt"></i>
                            <p>(555) 123-4567</p>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <p>info@burgerhub.com</p>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-clock"></i>
                            <p>Open Daily: 11AM - 10PM</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 BurgerHub. All rights reserved. | Designed and Developed by <strong>Muhammad Ahmad Khan</strong></p>
            </div>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile Menu Toggle
        const hamburger = document.querySelector('.hamburger');
        const navLinks = document.querySelector('.nav-links');
        
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            hamburger.innerHTML = navLinks.classList.contains('active') ? 
                '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                if (navLinks.classList.contains('active')) {
                    navLinks.classList.remove('active');
                    hamburger.innerHTML = '<i class="fas fa-bars"></i>';
                }
            });
        });
    </script>
</body>
</html>