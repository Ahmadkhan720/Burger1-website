<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Burger Palace - Contact Us</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            background-color: #f8f8f8;
            color: #333;
        }
        
        header {
            background-color: #ff6b00;
            color: white;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .logo {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        nav {
            background-color: #e65c00;
            padding: 15px 0;
        }
        
        nav ul {
            display: flex;
            justify-content: center;
            list-style: none;
        }
        
        nav ul li {
            margin: 0 20px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.1rem;
            transition: color 0.3s;
        }
        
        nav ul li a:hover {
            color: #ffcc00;
        }
        
        .contact-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        
        .contact-info {
            flex: 1;
            min-width: 300px;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            margin-right: 20px;
            margin-bottom: 20px;
        }
        
        .contact-form {
            flex: 1;
            min-width: 300px;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        h2 {
            color: #ff6b00;
            margin-bottom: 20px;
            font-size: 2rem;
        }
        
        .info-item {
            margin-bottom: 25px;
            display: flex;
            align-items: flex-start;
        }
        
        .info-item i {
            font-size: 1.5rem;
            color: #ff6b00;
            margin-right: 15px;
            margin-top: 5px;
        }
        
        .info-text h3 {
            font-size: 1.2rem;
            margin-bottom: 5px;
            color: #333;
        }
        
        .info-text p {
            color: #666;
            line-height: 1.5;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
            transition: border 0.3s;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #ff6b00;
            outline: none;
        }
        
        .form-group textarea {
            height: 150px;
            resize: vertical;
        }
        
        .submit-btn {
            background-color: #ff6b00;
            color: white;
            border: none;
            padding: 12px 25px;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .submit-btn:hover {
            background-color: #e65c00;
        }
        
        .map {
            width: 100%;
            height: 400px;
            margin-top: 40px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        
        .map iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 30px 0;
            margin-top: 50px;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .social-icons {
            margin: 20px 0;
        }
        
        .social-icons a {
            color: white;
            font-size: 1.5rem;
            margin: 0 10px;
            transition: color 0.3s;
        }
        
        .social-icons a:hover {
            color: #ff6b00;
        }
        
        .credits {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #aaa;
        }
        
        .developer-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 8px 15px;
            background-color: #ff6b00;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 0.9rem;
            transition: background-color 0.3s;
        }
        
        .developer-btn:hover {
            background-color: #e65c00;
        }
        
        @media (max-width: 768px) {
            .contact-info, .contact-form {
                margin-right: 0;
                width: 100%;
            }
            
            nav ul {
                flex-direction: column;
                align-items: center;
            }
            
            nav ul li {
                margin: 5px 0;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="logo">Burger Palace</div>
    </header>    
    <div class="contact-container">
        <div class="contact-info">
            <h2>Get In Touch</h2>
            <div class="info-item">
                <i class="fas fa-map-marker-alt"></i>
                <div class="info-text">
                    <h3>Our Location</h3>
                    <p>123 Burger Street, Foodville, NY 10001</p>
                </div>
            </div>
            <div class="info-item">
                <i class="fas fa-phone"></i>
                <div class="info-text">
                    <h3>Call Us</h3>
                    <p>+1 (555) 123-4567</p>
                    <p>+1 (555) 765-4321</p>
                </div>
            </div>
            <div class="info-item">
                <i class="fas fa-envelope"></i>
                <div class="info-text">
                    <h3>Email Us</h3>
                    <p>info@burgerpalace.com</p>
                    <p>support@burgerpalace.com</p>
                </div>
            </div>
            <div class="info-item">
                <i class="fas fa-clock"></i>
                <div class="info-text">
                    <h3>Opening Hours</h3>
                    <p>Monday - Friday: 10:00 AM - 10:00 PM</p>
                    <p>Saturday - Sunday: 11:00 AM - 11:00 PM</p>
                </div>
            </div>
        </div>
        
        <div class="contact-form">
            <h2>Send Us a Message</h2>
            <form action="#" method="POST">
                <div class="form-group">
                    <label for="name">Your Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Your Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" required>
                </div>
                <div class="form-group">
                    <label for="message">Your Message</label>
                    <textarea id="message" name="message" required></textarea>
                </div>
                <button type="submit" class="submit-btn">Send Message</button>
            </form>
        </div>
    </div>
    
    <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.215209105331!2d-73.987844924164!3d40.7484409713899!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259a9b3117469%3A0xd134e199a405a163!2sEmpire%20State%20Building!5e0!3m2!1sen!2sus!4v1629990000000!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
    </div>
    
    <footer>
        <div class="footer-content">
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
            <p>&copy; 2025 burger place All Rights Reserved.</p>
            <a href="#" class="developer-btn">Developed and Designed by Muhammad Ahmad Khan</a>
            <div class="credits">
                <p>Images may be subject to copyright. Used for demonstration purposes only.</p>
            </div>
        </div>
    </footer>
</body>
</html>