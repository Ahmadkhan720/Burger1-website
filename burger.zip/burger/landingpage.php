<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🍔 BurgerHub - Home of World's Best Burgers (2025)</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            scroll-behavior: smooth;
        }

        :root {
            --primary: #ff6b00;
            --primary-dark: #e05a00;
            --secondary: #333;
            --light: #f8f8f8;
            --dark: #222;
            --text: #444;
            --shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        body {
            background: var(--light);
            color: var(--text);
            overflow-x: hidden;
            line-height: 1.6;
        }

        h1, h2, h3, h4 {
            color: var(--secondary);
            line-height: 1.2;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        section {
            padding: 80px 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 60px;
            position: relative;
        }

        .section-title h2 {
            font-size: 2.5rem;
            display: inline-block;
            position: relative;
        }

        .section-title h2 span {
            color: var(--primary);
        }

        .section-title h2::after {
            content: '';
            position: absolute;
            width: 80px;
            height: 3px;
            background: var(--primary);
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
        }

        .btn {
            display: inline-block;
            padding: 12px 30px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            text-align: center;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
            border: 5px solid var(--primary);
            border-radius:10px;
            padding:10px;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(255, 107, 0, 0.2);
        }

        .btn-secondary {
            background: transparent;
            color: white;
            border: 2px solid white;
             border-radius:10px;
            padding:10px;
        }

        .btn-secondary:hover {
            background: white;
            color: var(--secondary);
            transform: translateY(-3px);
        }

        /* ===== NAVIGATION ===== */
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 5%;
            background: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        nav.scrolled {
            padding: 15px 5%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
        }

        .logo a {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--secondary);
            text-decoration: none;
        }

        .logo span {
            color: var(--primary);
        }

        .nav-links {
            display: flex;
            list-style: none;
        }

        .nav-links li {
            margin-left: 30px;
            position: relative;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--secondary);
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            background: var(--primary);
            bottom: -5px;
            left: 0;
            transition: width 0.3s ease;
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .nav-links a.active {
            color: var(--primary);
        }

        .nav-links a.active::after {
            width: 100%;
        }

        .btn-login {
            background: var(--primary);
            color: white !important;
            padding: 8px 20px;
            border-radius: 5px;
            margin-left: 20px;
        }

        .btn-login:hover {
            background: var(--primary-dark);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(255, 107, 0, 0.2);
        }

        .btn-login::after {
            display: none;
        }

        .hamburger {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--secondary);
        }

        /* ===== HERO SLIDESHOW SECTION ===== */
        .hero-slideshow {
            height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center;
            opacity: 0;
            transition: opacity 1s ease-in-out;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;
        }

        .slide.active {
            opacity: 1;
        }

        .slide::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
        }

        .slide-content {
            position: relative;
            z-index: 1;
            max-width: 800px;
            padding: 0 20px;
            transform: translateY(20px);
            transition: transform 1s ease;
        }

        .slide.active .slide-content {
            transform: translateY(0);
        }

        .slide h1 {
            font-size: 4rem;
            margin-bottom: 20px;
            color: white;
        }

        .slide span {
            color: var(--primary);
        }

        .slide p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            opacity: 0.9;
        }

        .slide-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        .slideshow-nav {
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 10px;
            z-index: 2;
        }

        .slideshow-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .slideshow-dot.active {
            background: var(--primary);
            transform: scale(1.2);
        }

        .scroll-down {
            position: absolute;
            bottom: 70px;
            left: 50%;
            transform: translateX(-50%);
            color: white;
            font-size: 1.5rem;
            animation: bounce 2s infinite;
            cursor: pointer;
            z-index: 2;
        }

        /* ===== ABOUT BURGERS SECTION ===== */
        .about-burgers {
            background: white;
            position: relative;
            overflow: hidden;
        }

        .about-burgers::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('https://images.unsplash.com/photo-1607013251379-e6aec68aa5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80') no-repeat center/cover;
            opacity: 0.03;
            z-index: 0;
        }

        .about-content {
            position: relative;
            z-index: 1;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 50px;
            align-items: center;
        }

        .about-text h3 {
            font-size: 1.8rem;
            margin-bottom: 20px;
            color: var(--secondary);
        }

        .about-text h3 span {
            color: var(--primary);
        }

        .about-text p {
            margin-bottom: 15px;
        }

        .about-image {
            position: relative;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .about-image img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.5s ease;
        }

        .about-image:hover img {
            transform: scale(1.05);
        }

        /* ===== BURGER TYPES SECTION ===== */
        .burger-types {
            background: var(--light);
        }

        .types-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .type-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
        }

        .type-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .type-image {
            height: 200px;
            overflow: hidden;
        }

        .type-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .type-card:hover .type-image img {
            transform: scale(1.1);
        }

        .type-content {
            padding: 20px;
        }

        .type-content h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--secondary);
        }

        .type-content p {
            margin-bottom: 15px;
            color: var(--text);
        }

        .type-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }

        .type-price {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--primary);
        }

        /* ===== OUR STORY SECTION ===== */
        .our-story {
            background: url('https://images.unsplash.com/photo-1512152272829-e3139592d56f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80') no-repeat center/cover fixed;
            color: white;
            position: relative;
            text-align: center;
        }

        .our-story::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
        }

        .story-content {
            position: relative;
            z-index: 1;
            max-width: 800px;
            margin: 0 auto;
        }

        .story-content h2 {
            color: white;
        }

        .story-content h2::after {
            background: var(--primary);
        }

        .story-content p {
            margin-bottom: 20px;
            font-size: 1.1rem;
        }

        .milestones {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            margin-top: 50px;
        }

        .milestone {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(5px);
            padding: 30px 20px;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }

        .milestone:hover {
            background: rgba(255, 107, 0, 0.2);
            transform: translateY(-5px);
        }

        .milestone i {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .milestone h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: white;
        }

        .milestone p {
            font-size: 1rem;
            margin-bottom: 0;
        }

        /* ===== DEVELOPER SECTION ===== */
        .developer-section {
            background: white;
            padding: 80px 0;
        }

        .developer-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 50px;
            align-items: center;
        }

        .developer-image {
            position: relative;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .developer-image img {
            width: 100%;
            height: auto;
            display: block;
        }

        .developer-info {
            position: relative;
        }

        .developer-info h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: var(--secondary);
        }

        .developer-info h2 span {
            color: var(--primary);
        }

        .developer-info h3 {
            font-size: 1.3rem;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .developer-info p {
            margin-bottom: 15px;
        }

        .developer-skills {
            margin-top: 20px;
        }

        .developer-skills h4 {
            margin-bottom: 10px;
            font-size: 1.1rem;
        }

        .skills-list {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .skill-tag {
            background: var(--light);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            color: var(--secondary);
        }

        /* ===== TESTIMONIALS SECTION ===== */
        .testimonials {
            background: var(--light);
        }

        .testimonials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .testimonial-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: var(--shadow);
            position: relative;
        }

        .testimonial-card::before {
            content: '\201C';
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 4rem;
            color: rgba(255, 107, 0, 0.1);
            font-family: Georgia, serif;
            line-height: 1;
        }

        .testimonial-content {
            position: relative;
            z-index: 1;
        }

        .testimonial-text {
            font-style: italic;
            margin-bottom: 20px;
            color: var(--text);
        }

        .testimonial-author {
            display: flex;
            align-items: center;
        }

        .author-image {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            overflow: hidden;
            margin-right: 15px;
        }

        .author-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .author-info h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--secondary);
        }

        .author-info p {
            font-size: 0.9rem;
            color: var(--primary);
        }

        /* ===== CTA SECTION ===== */
        .cta {
            background: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)), url('https://images.unsplash.com/photo-1604135307399-86c6ce0aba8e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80') no-repeat center/cover;
            color: white;
            text-align: center;
            padding: 100px 0;
        }

        .cta h2 {
            color: white;
            margin-bottom: 20px;
        }

        .cta h2 span {
            color: var(--primary);
        }

        .cta p {
            max-width: 700px;
            margin: 0 auto 30px;
            font-size: 1.1rem;
        }

        .cta-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        /* ===== FOOTER ===== */
        footer {
            background: var(--secondary);
            color: white;
            padding: 60px 0 20px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .footer-logo {
            margin-bottom: 20px;
        }

        .footer-logo a {
            font-size: 1.8rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }

        .footer-logo span {
            color: var(--primary);
        }

        .footer-about p {
            margin-bottom: 20px;
            opacity: 0.8;
        }

        .footer-links h3, .footer-contact h3 {
            font-size: 1.3rem;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-links h3::after, .footer-contact h3::after {
            content: '';
            position: absolute;
            width: 50px;
            height: 2px;
            background: var(--primary);
            bottom: 0;
            left: 0;
        }

        .footer-links ul {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: white;
            opacity: 0.8;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-links a:hover {
            opacity: 1;
            color: var(--primary);
            padding-left: 5px;
        }

        .contact-info {
            margin-bottom: 20px;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .contact-item i {
            color: var(--primary);
            margin-right: 10px;
            margin-top: 5px;
        }

        .social-links {
            display: flex;
            gap: 15px;
        }

        .social-links a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            color: white;
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            background: var(--primary);
            transform: translateY(-3px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-bottom p {
            opacity: 0.7;
            font-size: 0.9rem;
        }

        /* ===== ANIMATIONS ===== */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0) translateX(-50%);
            }
            40% {
                transform: translateY(-20px) translateX(-50%);
            }
            60% {
                transform: translateY(-10px) translateX(-50%);
            }
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 992px) {
            .section-title h2 {
                font-size: 2.2rem;
            }
            
            .slide h1 {
                font-size: 3.5rem;
            }
        }

        @media (max-width: 768px) {
            .nav-links {
                position: fixed;
                top: 80px;
                left: -100%;
                width: 100%;
                height: calc(100vh - 80px);
                background: white;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                transition: all 0.5s ease;
            }

            .nav-links.active {
                left: 0;
            }

            .nav-links li {
                margin: 15px 0;
            }

            .hamburger {
                display: block;
            }

            .slide h1 {
                font-size: 2.8rem;
            }

            .slide-buttons {
                flex-direction: column;
                gap: 15px;
            }

            .btn {
                width: 100%;
            }

            .section-title h2 {
                font-size: 2rem;
            }
        }

        @media (max-width: 576px) {
            .slide h1 {
                font-size: 2.2rem;
            }

            .slide p {
                font-size: 1rem;
            }

            .section-title h2 {
                font-size: 1.8rem;
            }

            .cta-buttons {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- ===== NAVIGATION ===== -->
    <nav id="navbar">
        <div class="logo">
            <a href="landingpage.php">Burger<span>Hub</span></a>
        </div>
        <ul class="nav-links">
            <li><a href="#home" class="active">Home</a></li>
         <li><a href="#types">Burger Types</a></li>
            <li><a href="aboutburger.php">About Burgers</a></li>
            <li><a href="order.php">Order Now</a></li>
            <li><a href="login.php" class="btn-login">Login</a></li>
        </ul>
        <div class="hamburger">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <!-- ===== HERO SLIDESHOW SECTION ===== -->
    <section class="hero-slideshow" id="home">
        <!-- Slide 1 -->
        <div class="slide active" style="background-image: url('https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80')">
            <div class="slide-content">
                <h1>Crafting Burger Perfection <span>Since 2025</span></h1>
                <p>Experience the revolution in burger craftsmanship with our 100% organic, hand-pressed patties and artisanal buns baked fresh daily.</p>
                <div class="slide-buttons">
                    <a href="order.php" class="btn-primary">Order Now</a>
                    <a href="#about" class="btn-secondary">Explore Menu</a>
                </div>
            </div>
        </div>
        
        <!-- Slide 2 -->
        <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1553979459-d2229ba7433b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80')">
            <div class="slide-content">
                <h1>Premium Ingredients <span>Unmatched Quality</span></h1>
                <p>Our burgers are made with grass-fed beef, locally sourced vegetables, and house-made sauces for an unforgettable taste experience.</p>
                <div class="slide-buttons">
                    <a href="order.php" class="btn-primary">Order Now</a>
                    <a href="#types" class="btn-secondary">View Menu</a>
                </div>
            </div>
        </div>
        
        <!-- Slide 3 -->
        <div class="slide" style="background-image: url('https://images.unsplash.com/photo-1586190848861-99aa4a171e90?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80')">
            <div class="slide-content">
                <h1>Gourmet Burgers <span>For Every Taste</span></h1>
                <p>From classic cheeseburgers to innovative vegan options, we have something to satisfy every craving.</p>
                <div class="slide-buttons">
                    <a href="order.php" class="btn-primary">Order Now</a>
                    <a href="#story" class="btn-secondary">Our Story</a>
                </div>
            </div>
        </div>
        
        <div class="scroll-down" onclick="scrollToSection('about')">
            <i class="fas fa-chevron-down"></i>
        </div>
        
        <div class="slideshow-nav">
            <div class="slideshow-dot active" data-slide="0"></div>
            <div class="slideshow-dot" data-slide="1"></div>
            <div class="slideshow-dot" data-slide="2"></div>
        </div>
    </section>

    <!-- ===== ABOUT BURGERS SECTION ===== -->
    <section class="about-burgers" id="about">
        <div class="container">
            <div class="section-title">
                <h2>The Art of <span>Burger Crafting</span></h2>
            </div>
            <div class="about-content">
                <div class="about-text">
                    <h3>Why Our Burgers Are <span>Different</span></h3>
                    <p>At BurgerHub, we've redefined what it means to be a premium burger. Our journey begins with ethically sourced, grass-fed beef that's never frozen, ensuring maximum flavor and juiciness in every bite.</p>
                    <p>Our signature blend combines three premium cuts of beef, hand-ground daily and seasoned with our proprietary spice mix developed by world-class chefs. The patties are pressed to order, never pre-formed, guaranteeing that fresh-from-the-grill taste.</p>
                    <p>The buns are no afterthought - we've partnered with local bakeries to create the perfect vehicle for our burgers. Baked fresh throughout the day, they're soft yet sturdy, with a slight sweetness that complements our savory creations.</p>
                    <a href="#types" class="btn-primary">Explore Our Creations</a>
                </div>
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1550547660-d9450f859349?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" alt="Burger Preparation">
                </div>
            </div>
        </div>
    </section>

    <!-- ===== BURGER TYPES SECTION ===== -->
    <section class="burger-types" id="types">
        <div class="container">
            <div class="section-title">
                <h2>Our Signature <span>Creations</span></h2>
            </div>
            <div class="types-grid">
                <!-- Classic Burger -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Classic Burger">
                    </div>
                    <div class="type-content">
                        <h3>The Classic</h3>
                        <p>Our timeless masterpiece featuring a 1/3 lb grass-fed beef patty, aged cheddar, crisp lettuce, vine-ripened tomato, red onion, and our signature sauce on a brioche bun.</p>
                        <div class="type-meta">
                            <span class="type-price">$9.99</span>
                            <a href="order.php" class="btn-primary">Order Now</a>
                        </div>
                    </div>
                </div>

                <!-- Bacon King -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1553979459-d2229ba7433b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Bacon King Burger">
                    </div>
                    <div class="type-content">
                        <h3>Bacon King</h3>
                        <p>Double 1/3 lb patties, six strips of applewood-smoked bacon, American cheese, crispy onions, and our smoky BBQ sauce on a pretzel bun.</p>
                        <div class="type-meta">
                            <span class="type-price">$12.99</span>
                            <a href="order.php" class="btn-primary">Order Now</a>
                        </div>
                    </div>
                </div>

                <!-- Vegan Delight -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1596662951482-0c4ba74a6df6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Vegan Burger">
                    </div>
                    <div class="type-content">
                        <h3>Vegan Delight</h3>
                        <p>House-made black bean and quinoa patty with roasted portobello, avocado, vegan chipotle mayo, and organic sprouts on a whole grain bun.</p>
                        <div class="type-meta">
                            <span class="type-price">$10.99</span>
                            <a href="order.php" class="btn-primary">Order Now</a>
                        </div>
                    </div>
                </div>

                <!-- Spicy Jalapeño -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1596662951482-0c4ba74a6df6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Spicy Jalapeño Burger">
                    </div>
                    <div class="type-content">
                        <h3>Spicy Jalapeño</h3>
                        <p>1/2 lb beef patty infused with jalapeños, topped with pepper jack cheese, crispy jalapeño chips, chipotle aioli, and fresh jalapeño slices.</p>
                        <div class="type-meta">
                            <span class="type-price">$11.99</span>
                            <a href="order.php" class="btn-primary">Order Now</a>
                        </div>
                    </div>
                </div>

                <!-- Truffle Mushroom -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1586190848861-99aa4a171e90?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Truffle Mushroom Burger">
                    </div>
                    <div class="type-content">
                        <h3>Truffle Mushroom</h3>
                        <p>Wagyu beef patty with wild mushroom ragout, truffle aioli, melted Gruyère cheese, and arugula on a black truffle brioche bun.</p>
                        <div class="type-meta">
                            <span class="type-price">$15.99</span>
                            <a href="order.php" class="btn-primary">Order Now</a>
                        </div>
                    </div>
                </div>

                <!-- Hawaiian Luau -->
                <div class="type-card">
                    <div class="type-image">
                        <img src="https://images.unsplash.com/photo-1565299507177-b0ac66763828?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Hawaiian Burger">
                    </div>
                    <div class="type-content">
                        <h3>Hawaiian Luau</h3>
                        <p>Grass-fed beef with grilled pineapple, teriyaki glaze, smoked Gouda, crispy onion strings, and sriracha mayo on a Hawaiian sweet roll.</p>
                        <div class="type-meta">
                            <span class="type-price">$12.99</span>
                            <a href="order.php" class="btn-primary">Order Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== OUR STORY SECTION ===== -->
    <section class="our-story" id="story">
        <div class="container">
            <div class="story-content">
                <div class="section-title">
                    <h2>Our <span>Journey</span></h2>
                </div>
                <p>Founded in 2025, BurgerHub began as a humble food truck with a big dream - to revolutionize the burger industry. What started as a single mobile kitchen serving downtown has grown into a beloved institution with multiple locations across the city.</p>
                <p>Our founder, Chef Michael Rodriguez, spent years perfecting the art of burger-making before introducing his creations to the public. His philosophy was simple: use only the finest ingredients, treat every customer like family, and never compromise on quality.</p>
                <p>Today, we continue this tradition, sourcing our ingredients from local farmers and artisans who share our commitment to sustainability and excellence. Every burger tells a story - of passion, craftsmanship, and the pursuit of perfection.</p>
                
                <div class="milestones">
                    <div class="milestone">
                        <i class="fas fa-calendar-alt"></i>
                        <h3>2025</h3>
                        <p>Founded as a single food truck in downtown</p>
                    </div>
                    <div class="milestone">
                        <i class="fas fa-store"></i>
                        <h3>2026</h3>
                        <p>Opened our first brick-and-mortar location</p>
                    </div>
                    <div class="milestone">
                        <i class="fas fa-award"></i>
                        <h3>2027</h3>
                        <p>Voted "Best Burger in the City"</p>
                    </div>
                    <div class="milestone">
                        <i class="fas fa-utensils"></i>
                        <h3>Today</h3>
                        <p>Serving thousands of happy customers weekly</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== DEVELOPER SECTION ===== -->
    <section class="developer-section" id="developer">
        <div class="container">
            <div class="section-title">
                <h2>About The <span>Developer</span></h2>
            </div>
            <div class="developer-container">
                <div class="developer-image">
                    <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Muhammad Ahmad Khan">
                </div>
                <div class="developer-info">
                    <h2>Muhammad Ahmad <span>Khan</span></h2>
                    <h3>Full Stack Web Developer & Designer</h3>
                    <p>With over 5 years of experience in web development, Muhammad Ahmad Khan specializes in creating beautiful, functional websites that drive results. This BurgerHub website represents his commitment to clean code, responsive design, and user-friendly interfaces.</p>
                    <p>Graduating with honors in Computer Science in 2020, Muhammad has since worked with numerous clients across various industries, helping them establish a powerful online presence. His expertise spans front-end technologies like HTML5, CSS3, JavaScript, and modern frameworks, as well as back-end development with Node.js and Python.</p>
                    <p>When not coding, Muhammad enjoys exploring new culinary trends, which inspired the creation of this burger website. He believes that great food and great websites share common principles - quality ingredients, careful preparation, and attention to detail.</p>
                    
                    <div class="developer-skills">
                        <h4>Technical Skills:</h4>
                        <div class="skills-list">
                            <span class="skill-tag">HTML5</span>
                            <span class="skill-tag">CSS3</span>
                            <span class="skill-tag">JavaScript</span>
                            <span class="skill-tag">React</span>
                            <span class="skill-tag">Node.js</span>
                            <span class="skill-tag">Python</span>
                            <span class="skill-tag">UI/UX Design</span>
                            <span class="skill-tag">Responsive Design</span>
                        </div>
                    </div>
                    
                    <a href="contact.html" class="btn-primary" style="margin-top: 20px;">Contact Developer</a>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== TESTIMONIALS SECTION ===== -->
    <section class="testimonials">
        <div class="container">
            <div class="section-title">
                <h2>What Our <span>Customers</span> Say</h2>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <p class="testimonial-text">"The best burger I've ever had! The quality of ingredients is exceptional, and you can taste the difference. The Classic Burger is my go-to, but I'm working my way through the entire menu. Worth every penny!"</p>
                        <div class="testimonial-author">
                            <div class="author-image">
                                <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Sarah Johnson">
                            </div>
                            <div class="author-info">
                                <h4>Sarah Johnson</h4>
                                <p>Food Blogger</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <p class="testimonial-text">"As a chef, I'm incredibly picky about burgers. BurgerHub has set a new standard. The patty-to-bun ratio is perfect, the cheese is always melted just right, and their special sauce is addictive. The Spicy Jalapeño is a masterpiece!"</p>
                        <div class="testimonial-author">
                            <div class="author-image">
                                <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Michael Chen">
                            </div>
                            <div class="author-info">
                                <h4>Michael Chen</h4>
                                <p>Executive Chef</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <p class="testimonial-text">"I was skeptical about vegan burgers until I tried BurgerHub's Vegan Delight. The texture is amazing, and the flavors are so well-balanced. Even my meat-loving friends were impressed. Now we come here every Friday!"</p>
                        <div class="testimonial-author">
                            <div class="author-image">
                                <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Emily Rodriguez">
                            </div>
                            <div class="author-info">
                                <h4>Emily Rodriguez</h4>
                                <p>Regular Customer</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== CTA SECTION ===== -->
    <section class="cta">
        <div class="container">
            <h2>Ready to Experience <span>Burger Perfection</span>?</h2>
            <p>Join thousands of satisfied customers and taste the difference that quality ingredients and expert preparation make. Order online now for quick pickup or delivery!</p>
            <div class="cta-buttons">
                <a href="order.php" class="btn-primary">Order Now</a>
                <!-- <a href="contact.html" class="btn-secondary">Contact Us</a> -->
            </div>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <div class="footer-logo">
                        <a href="index.html">Burger<span>Hub</span></a>
                    </div>
                    <p>Crafting exceptional burgers since 2025. Our commitment to quality ingredients and culinary excellence sets us apart in the burger industry.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-yelp"></i></a>
                    </div>
                </div>

                <div class="footer-links">
                    <h3>Quick Links</h3>
                    <ul>
                      <li><a href="landingpage.php">Home</a></li>
                        <li><a href="order.php">Order Online</a></li>
                        <li><a href="aboutburgers.php">About Burgers</a></li>
                        <li><a href="aboutus.phpl">About Us</a></li>
                        <li><a href="contactus.php">Contact</a></li>
                    </ul>
                </div>

                <div class="footer-contact">
                    <h3>Contact Us</h3>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <p>123 Burger Street, Food City, FC 12345</p>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone-alt"></i>
                            <p>(555) 123-4567</p>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <p>info@burgerhub.com</p>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-clock"></i>
                            <p>Open Daily: 11AM - 10PM</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 BurgerHub. All rights reserved. | Designed and Developed by <strong>Muhammad Ahmad Khan</strong></p>
            </div>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile Menu Toggle
        const hamburger = document.querySelector('.hamburger');
        const navLinks = document.querySelector('.nav-links');
        
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            hamburger.innerHTML = navLinks.classList.contains('active') ? 
                '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
        });

        // Close mobile menu when clicking a link
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                hamburger.innerHTML = '<i class="fas fa-bars"></i>';
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Smooth scrolling for anchor links
        function scrollToSection(sectionId) {
            const section = document.getElementById(sectionId);
            window.scrollTo({
                top: section.offsetTop - 80,
                behavior: 'smooth'
            });
        }

        // Set active nav link based on scroll position
        const sections = document.querySelectorAll('section');
        const navItems = document.querySelectorAll('.nav-links a');

        window.addEventListener('scroll', () => {
            let current = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (pageYOffset >= (sectionTop - 100)) {
                    current = section.getAttribute('id');
                }
            });

            navItems.forEach(item => {
                item.classList.remove('active');
                if (item.getAttribute('href') === `#${current}`) {
                    item.classList.add('active');
                }
            });
        });

        // Animation on scroll
        const animateOnScroll = () => {
            const elements = document.querySelectorAll('.type-card, .milestone, .testimonial-card');
            
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.3;
                
                if (elementPosition < screenPosition) {
                    element.style.opacity = '1';
                    element.style.transform = 'translateY(0)';
                }
            });
        };

        // Set initial state for animated elements
        document.querySelectorAll('.type-card, .milestone, .testimonial-card').forEach(element => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';
            element.style.transition = 'all 0.5s ease';
        });

        // Slideshow functionality
        let currentSlide = 0;
        const slides = document.querySelectorAll('.slide');
        const dots = document.querySelectorAll('.slideshow-dot');
        const slideInterval = 5000; // 5 seconds
        
        function showSlide(index) {
            // Hide all slides
            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));
            
            // Show current slide
            slides[index].classList.add('active');
            dots[index].classList.add('active');
            currentSlide = index;
        }
        
        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }
        
        // Start slideshow
        let slideTimer = setInterval(nextSlide, slideInterval);
        
        // Pause on hover
        const slideshow = document.querySelector('.hero-slideshow');
        slideshow.addEventListener('mouseenter', () => clearInterval(slideTimer));
        slideshow.addEventListener('mouseleave', () => {
            slideTimer = setInterval(nextSlide, slideInterval);
        });
        
        // Dot navigation
        dots.forEach(dot => {
            dot.addEventListener('click', function() {
                clearInterval(slideTimer);
                const slideIndex = parseInt(this.getAttribute('data-slide'));
                showSlide(slideIndex);
                slideTimer = setInterval(nextSlide, slideInterval);
            });
        });

        window.addEventListener('scroll', animateOnScroll);
        window.addEventListener('load', animateOnScroll);
    </script>
</body>
</html>