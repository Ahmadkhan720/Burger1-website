<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🍔 BurgerHub - Order Now (2025)</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        :root {
            --primary: #ff6b00;
            --primary-dark: #e05a00;
            --secondary: #333;
            --light: #f8f8f8;
            --dark: #222;
            --text: #444;
            --shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }

        body {
            background: var(--light);
            color: var(--text);
            overflow-x: hidden;
            line-height: 1.6;
        }

        h1, h2, h3, h4 {
            color: var(--secondary);
            line-height: 1.2;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        section {
            padding: 80px 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 40px;
            position: relative;
        }

        .section-title h2 {
            font-size: 2.5rem;
            display: inline-block;
        }

        .section-title h2 span {
            color: var(--primary);
        }

        .btn {
            display: inline-block;
            padding: 12px 30px;
            border-radius: var(--radius);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            text-align: center;
            cursor: pointer;
            border: none;
            font-size: 1rem;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(255, 107, 0, 0.2);
        }

        .btn-outline {
            background: transparent;
            color: var(--primary);
            border: 2px solid var(--primary);
        }

        .btn-outline:hover {
            background: var(--primary);
            color: white;
        }

        /* ===== NAVIGATION ===== */
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 5%;
            background: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            z-index: 1000;
        }

        .logo a {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--secondary);
            text-decoration: none;
        }

        .logo span {
            color: var(--primary);
        }

        .nav-links {
            display: flex;
            list-style: none;
        }

        .nav-links li {
            margin-left: 30px;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--secondary);
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        .nav-links a.active {
            color: var(--primary);
            font-weight: 600;
        }

        .cart-icon {
            position: relative;
            margin-left: 30px;
        }

        .cart-count {
            position: absolute;
            top: -10px;
            right: -10px;
            background: var(--primary);
            color: white;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: 700;
        }

        .hamburger {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* ===== MENU SECTION ===== */
        .menu-container {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 40px;
            padding-top: 100px;
        }

        .menu-categories {
            margin-bottom: 30px;
        }

        .category-tabs {
            display: flex;
            overflow-x: auto;
            padding-bottom: 10px;
            margin-bottom: 30px;
        }

        .category-tab {
            padding: 10px 20px;
            background: white;
            border-radius: 30px;
            margin-right: 10px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            white-space: nowrap;
            border: 1px solid #eee;
        }

        .category-tab.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .category-tab:hover:not(.active) {
            background: #f5f5f5;
        }

        .menu-items {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }

        .menu-item {
            background: white;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            position: relative;
        }

        .menu-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .menu-item-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: var(--primary);
            color: white;
            padding: 5px 10px;
            border-radius: 30px;
            font-size: 0.8rem;
            font-weight: 600;
            z-index: 1;
        }

        .menu-item-img {
            height: 200px;
            overflow: hidden;
        }

        .menu-item-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .menu-item:hover .menu-item-img img {
            transform: scale(1.05);
        }

        .menu-item-content {
            padding: 20px;
        }

        .menu-item-title {
            font-size: 1.3rem;
            margin-bottom: 10px;
            color: var(--secondary);
        }

        .menu-item-desc {
            color: var(--text);
            margin-bottom: 15px;
            font-size: 0.9rem;
        }

        .menu-item-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .menu-item-price {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--primary);
        }

        .menu-item-add {
            background: var(--primary);
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
        }

        .menu-item-add:hover {
            background: var(--primary-dark);
            transform: rotate(90deg);
        }

        /* ===== CART SECTION ===== */
        .cart-sidebar {
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 25px;
            position: sticky;
            top: 120px;
            height: fit-content;
        }

        .cart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }

        .cart-title {
            font-size: 1.5rem;
        }

        .cart-clear {
            color: var(--primary);
            background: none;
            border: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .cart-clear:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        .cart-items {
            max-height: 400px;
            overflow-y: auto;
            margin-bottom: 20px;
        }

        .cart-item {
            display: flex;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f5f5f5;
        }

        .cart-item-img {
            width: 60px;
            height: 60px;
            border-radius: var(--radius);
            overflow: hidden;
            margin-right: 15px;
        }

        .cart-item-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .cart-item-details {
            flex: 1;
        }

        .cart-item-name {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .cart-item-price {
            color: var(--primary);
            font-weight: 600;
        }

        .cart-item-actions {
            display: flex;
            align-items: center;
            margin-top: 5px;
        }

        .cart-item-qty {
            width: 30px;
            text-align: center;
            margin: 0 5px;
        }

        .cart-item-btn {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #f5f5f5;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .cart-item-btn:hover {
            background: var(--primary);
            color: white;
        }

        .cart-item-remove {
            margin-left: auto;
            color: #ff4d4d;
            background: none;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .cart-item-remove:hover {
            color: #cc0000;
        }

        .cart-summary {
            border-top: 1px solid #eee;
            padding-top: 20px;
        }

        .cart-total {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .cart-empty {
            text-align: center;
            padding: 40px 0;
            color: var(--text);
        }

        .cart-empty i {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 15px;
        }

        /* ===== CHECKOUT MODAL ===== */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal {
            background: white;
            border-radius: var(--radius);
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            padding: 30px;
            position: relative;
            transform: translateY(20px);
            transition: all 0.3s ease;
        }

        .modal-overlay.active .modal {
            transform: translateY(0);
        }

        .modal-close {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 1.5rem;
            background: none;
            border: none;
            cursor: pointer;
            color: var(--text);
        }

        .modal-title {
            margin-bottom: 20px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--radius);
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(255, 107, 0, 0.2);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .payment-methods {
            margin: 20px 0;
        }

        .payment-method {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--radius);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .payment-method:hover {
            border-color: var(--primary);
        }

        .payment-method input {
            margin-right: 10px;
        }

        .order-summary {
            background: #f9f9f9;
            border-radius: var(--radius);
            padding: 20px;
            margin-top: 20px;
        }

        .order-summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .order-summary-total {
            border-top: 1px solid #ddd;
            padding-top: 10px;
            margin-top: 10px;
            font-weight: 600;
        }

        /* ===== ORDER CONFIRMATION ===== */
        .order-confirmation {
            text-align: center;
            padding: 30px 0;
        }

        .order-confirmation i {
            font-size: 4rem;
            color: var(--primary);
            margin-bottom: 20px;
        }

        .order-confirmation h2 {
            margin-bottom: 15px;
        }

        .order-confirmation p {
            margin-bottom: 25px;
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 992px) {
            .menu-container {
                grid-template-columns: 1fr;
            }

            .cart-sidebar {
                position: static;
                margin-top: 40px;
            }
        }

        @media (max-width: 768px) {
            .nav-links {
                position: fixed;
                top: 80px;
                left: -100%;
                width: 100%;
                height: calc(100vh - 80px);
                background: white;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                transition: all 0.5s ease;
            }

            .nav-links.active {
                left: 0;
            }

            .nav-links li {
                margin: 15px 0;
            }

            .hamburger {
                display: block;
            }

            .section-title h2 {
                font-size: 2rem;
            }

            .menu-items {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .section-title h2 {
                font-size: 1.8rem;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- ===== NAVIGATION ===== -->
    <nav>
        <div class="logo">
            <a href="landingpage.php">Burger<span>Hub</span></a>
        </div>
        <ul class="nav-links">
            <li><a href="landingpage.php">Home</a></li>
            <!-- <li><a href="order.html" class="active">Order Now</a></li> -->
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="contactus.php">Contact</a></li>
            <li><a href="login.php">Login</a></li>
            <li class="cart-icon">
                <a href="#cart"><i class="fas fa-shopping-cart"></i></a>
                <span class="cart-count">0</span>
            </li>
        </ul>
        <div class="hamburger">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <!-- ===== MENU SECTION ===== -->
    <div class="container">
        <div class="menu-container">
            <div class="menu-content">
                <div class="section-title">
                    <h2>Our <span>Menu</span></h2>
                </div>

                <div class="menu-categories">
                    <div class="category-tabs">
                        <div class="category-tab active" data-category="all">All Items</div>
                        <div class="category-tab" data-category="classic">Classic Burgers</div>
                        <div class="category-tab" data-category="premium">Premium Burgers</div>
                        <div class="category-tab" data-category="vegan">Vegan Options</div>
                        <div class="category-tab" data-category="sides">Sides & Drinks</div>
                    </div>
                </div>

                <div class="menu-items">
                    <!-- Classic Cheeseburger -->
                    <div class="menu-item" data-category="classic">
                        <div class="menu-item-badge">Bestseller</div>
                        <div class="menu-item-img">
                            <img src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Classic Cheeseburger">
                        </div>
                        <div class="menu-item-content">
                            <h3 class="menu-item-title">Classic Cheeseburger</h3>
                            <p class="menu-item-desc">1/3 lb grass-fed beef, American cheese, lettuce, tomato, onion, pickles, special sauce</p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price">$9.99</span>
                                <button class="menu-item-add" data-id="1" data-name="Classic Cheeseburger" data-price="9.99" data-image="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Bacon King -->
                    <div class="menu-item" data-category="classic">
                        <div class="menu-item-img">
                            <img src="https://images.unsplash.com/photo-1553979459-d2229ba7433b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Bacon King">
                        </div>
                        <div class="menu-item-content">
                            <h3 class="menu-item-title">Bacon King</h3>
                            <p class="menu-item-desc">Two 1/3 lb patties, six bacon strips, American cheese, ketchup, mayo, sesame bun</p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price">$12.99</span>
                                <button class="menu-item-add" data-id="2" data-name="Bacon King" data-price="12.99" data-image="https://images.unsplash.com/photo-1553979459-d2229ba7433b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Spicy Jalapeño -->
                    <div class="menu-item" data-category="premium">
                        <div class="menu-item-badge">Spicy</div>
                        <div class="menu-item-img">
                            <img src="https://images.unsplash.com/photo-1603064752735-247bd16a97b1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Spicy Jalapeño">
                        </div>
                        <div class="menu-item-content">
                            <h3 class="menu-item-title">Spicy Jalapeño</h3>
                            <p class="menu-item-desc">Jalapeño-infused patty, pepper jack cheese, jalapeño chips, chipotle aioli, brioche bun</p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price">$11.99</span>
                                <button class="menu-item-add" data-id="3" data-name="Spicy Jalapeño" data-price="11.99" data-image="https://images.unsplash.com/photo-1603064752735-247bd16a97b1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Truffle Mushroom -->
                    <div class="menu-item" data-category="premium">
                        <div class="menu-item-badge">Chef's Special</div>
                        <div class="menu-item-img">
                            <img src="https://images.unsplash.com/photo-1586190848861-99aa4a171e90?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Truffle Mushroom">
                        </div>
                        <div class="menu-item-content">
                            <h3 class="menu-item-title">Truffle Mushroom</h3>
                            <p class="menu-item-desc">Wagyu beef, wild mushrooms, truffle aioli, Gruyère cheese, arugula, truffle bun</p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price">$15.99</span>
                                <button class="menu-item-add" data-id="4" data-name="Truffle Mushroom" data-price="15.99" data-image="https://images.unsplash.com/photo-1586190848861-99aa4a171e90?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Vegan Delight -->
                    <div class="menu-item" data-category="vegan">
                        <div class="menu-item-badge">Vegan</div>
                        <div class="menu-item-img">
                            <img src="https://images.unsplash.com/photo-1596662951482-0c4ba74a6df6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Vegan Delight">
                        </div>
                        <div class="menu-item-content">
                            <h3 class="menu-item-title">Vegan Delight</h3>
                            <p class="menu-item-desc">Black bean-quinoa patty, roasted portobello, avocado, vegan chipotle mayo, sprouts</p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price">$10.99</span>
                                <button class="menu-item-add" data-id="5" data-name="Vegan Delight" data-price="10.99" data-image="https://images.unsplash.com/photo-1596662951482-0c4ba74a6df6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Hawaiian Luau -->
                    <div class="menu-item" data-category="premium">
                        <div class="menu-item-img">
                            <img src="https://images.unsplash.com/photo-1565299507177-b0ac66763828?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Hawaiian Luau">
                        </div>
                        <div class="menu-item-content">
                            <h3 class="menu-item-title">Hawaiian Luau</h3>
                            <p class="menu-item-desc">Grilled pineapple, teriyaki glaze, smoked Gouda, crispy onions, sriracha mayo</p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price">$12.99</span>
                                <button class="menu-item-add" data-id="6" data-name="Hawaiian Luau" data-price="12.99" data-image="https://images.unsplash.com/photo-1565299507177-b0ac66763828?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- French Fries -->
                    <div class="menu-item" data-category="sides">
                        <div class="menu-item-img">
                            <img src="https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="French Fries">
                        </div>
                        <div class="menu-item-content">
                            <h3 class="menu-item-title">French Fries</h3>
                            <p class="menu-item-desc">Crispy golden fries with sea salt, served with ketchup or garlic aioli</p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price">$3.99</span>
                                <button class="menu-item-add" data-id="7" data-name="French Fries" data-price="3.99" data-image="https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Onion Rings -->
                    <div class="menu-item" data-category="sides">
                        <div class="menu-item-img">
                            <img src="https://images.unsplash.com/photo-1630447923252-f86106e84b4b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80" alt="Onion Rings">
                        </div>
                        <div class="menu-item-content">
                            <h3 class="menu-item-title">Onion Rings</h3>
                            <p class="menu-item-desc">Beer-battered onion rings with ranch dipping sauce</p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price">$4.99</span>
                                <button class="menu-item-add" data-id="8" data-name="Onion Rings" data-price="4.99" data-image="https://images.unsplash.com/photo-1630447923252-f86106e84b4b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ===== CART SIDEBAR ===== -->
            <div class="cart-sidebar">
                <div class="cart-header">
                    <h3 class="cart-title">Your Order</h3>
                    <button class="cart-clear">Clear All</button>
                </div>

                <div class="cart-items">
                    <!-- Cart items will be added here dynamically -->
                    <div class="cart-empty">
                        <i class="fas fa-shopping-cart"></i>
                        <p>Your cart is empty</p>
                    </div>
                </div>

                <div class="cart-summary">
                    <div class="cart-total">
                        <span>Total:</span>
                        <span class="cart-total-amount">$0.00</span>
                    </div>
                    <button class="btn btn-primary btn-checkout" style="width: 100%;">Proceed to Checkout</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== CHECKOUT MODAL ===== -->
    <div class="modal-overlay" id="checkoutModal">
        <div class="modal">
            <button class="modal-close">&times;</button>
            <h3 class="modal-title">Complete Your Order</h3>
            
            <form id="checkoutForm">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" class="form-control" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="street">Street Address</label>
                        <input type="text" id="street" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="city">City</label>
                        <input type="text" id="city" class="form-control" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="zip">ZIP Code</label>
                        <input type="text" id="zip" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="country">Country</label>
                        <input type="text" id="country" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Delivery Instructions</label>
                    <textarea id="instructions" class="form-control" rows="3"></textarea>
                </div>

                <div class="payment-methods">
                    <h4>Payment Method</h4>
                    <label class="payment-method">
                        <input type="radio" name="payment" value="card" checked> 
                        <i class="far fa-credit-card"></i> Credit/Debit Card
                    </label>
                    <label class="payment-method">
                        <input type="radio" name="payment" value="cash"> 
                        <i class="fas fa-money-bill-wave"></i> Cash on Delivery
                    </label>
                    <label class="payment-method">
                        <input type="radio" name="payment" value="paypal"> 
                        <i class="fab fa-paypal"></i> PayPal
                    </label>
                </div>

                <div class="order-summary">
                    <h4>Order Summary</h4>
                    <div id="modal-order-items">
                        <!-- Order items will be added here dynamically -->
                    </div>
                    <div class="order-summary-item">
                        <span>Subtotal:</span>
                        <span class="order-subtotal">$0.00</span>
                    </div>
                    <div class="order-summary-item">
                        <span>Delivery Fee:</span>
                        <span>$2.99</span>
                    </div>
                    <div class="order-summary-item order-summary-total">
                        <span>Total:</span>
                        <span class="order-total">$2.99</span>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 20px;">Place Order</button>
            </form>
        </div>
    </div>

    <!-- ===== ORDER CONFIRMATION MODAL ===== -->
    <div class="modal-overlay" id="confirmationModal">
        <div class="modal">
            <div class="order-confirmation">
                <i class="fas fa-check-circle"></i>
                <h2>Order Confirmed!</h2>
                <p>Thank you for your order. Your food will be prepared fresh and delivered to you shortly.</p>
                <p>Order ID: <strong>#BH2025-<span id="orderId">0000</span></strong></p>
                <button class="btn btn-primary" id="continueShopping">Continue Shopping</button>
            </div>
        </div>
    </div>

    <!-- ===== FOOTER ===== -->
    <footer style="background: var(--secondary); color: white; padding: 40px 0; text-align: center;">
        <div class="container">
            <p>&copy; 2025 BurgerHub. All rights reserved.</p>
            <p>Developed by <strong>Muhammad Ahmad Khan</strong></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile Menu Toggle
        const hamburger = document.querySelector('.hamburger');
        const navLinks = document.querySelector('.nav-links');
        
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            hamburger.innerHTML = navLinks.classList.contains('active') ? 
                '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
        });

        // Category Tabs
        const categoryTabs = document.querySelectorAll('.category-tab');
        const menuItems = document.querySelectorAll('.menu-item');

        categoryTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove active class from all tabs
                categoryTabs.forEach(t => t.classList.remove('active'));
                // Add active class to clicked tab
                tab.classList.add('active');
                
                const category = tab.dataset.category;
                
                // Filter menu items
                menuItems.forEach(item => {
                    if (category === 'all' || item.dataset.category === category) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });

        // Shopping Cart Functionality
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        const cartItemsEl = document.querySelector('.cart-items');
        const cartCountEl = document.querySelector('.cart-count');
        const cartTotalEl = document.querySelector('.cart-total-amount');
        const addToCartBtns = document.querySelectorAll('.menu-item-add');
        const clearCartBtn = document.querySelector('.cart-clear');
        const checkoutBtn = document.querySelector('.btn-checkout');

        // Update cart
        function updateCart() {
            renderCartItems();
            renderCartTotal();
            
            // Save to localStorage
            localStorage.setItem('cart', JSON.stringify(cart));
        }

        // Render cart items
        function renderCartItems() {
            cartItemsEl.innerHTML = '';
            
            if (cart.length === 0) {
                cartItemsEl.innerHTML = `
                    <div class="cart-empty">
                        <i class="fas fa-shopping-cart"></i>
                        <p>Your cart is empty</p>
                    </div>
                `;
                cartCountEl.textContent = '0';
                return;
            }
            
            cartCountEl.textContent = cart.reduce((total, item) => total + item.quantity, 0);
            
            cart.forEach(item => {
                cartItemsEl.innerHTML += `
                    <div class="cart-item" data-id="${item.id}">
                        <div class="cart-item-img">
                            <img src="${item.image}" alt="${item.name}">
                        </div>
                        <div class="cart-item-details">
                            <div class="cart-item-name">${item.name}</div>
                            <div class="cart-item-price">$${(item.price * item.quantity).toFixed(2)}</div>
                            <div class="cart-item-actions">
                                <button class="cart-item-btn minus"><i class="fas fa-minus"></i></button>
                                <input type="number" class="cart-item-qty" value="${item.quantity}" min="1">
                                <button class="cart-item-btn plus"><i class="fas fa-plus"></i></button>
                                <button class="cart-item-remove"><i class="fas fa-trash"></i></button>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            // Add event listeners to quantity buttons
            document.querySelectorAll('.minus').forEach(btn => {
                btn.addEventListener('click', decreaseQuantity);
            });
            
            document.querySelectorAll('.plus').forEach(btn => {
                btn.addEventListener('click', increaseQuantity);
            });
            
            document.querySelectorAll('.cart-item-remove').forEach(btn => {
                btn.addEventListener('click', removeItem);
            });
            
            document.querySelectorAll('.cart-item-qty').forEach(input => {
                input.addEventListener('change', updateQuantity);
            });
        }

        // Render cart total
        function renderCartTotal() {
            const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            cartTotalEl.textContent = `$${total.toFixed(2)}`;
        }

        // Add to cart
        function addToCart(id, name, price, image) {
            // Check if item already exists in cart
            const existingItem = cart.find(item => item.id === id);
            
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({
                    id,
                    name,
                    price: parseFloat(price),
                    image,
                    quantity: 1
                });
            }
            
            updateCart();
            
            // Show animation on add button
            const addBtn = document.querySelector(`.menu-item-add[data-id="${id}"]`);
            addBtn.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                addBtn.innerHTML = '<i class="fas fa-plus"></i>';
            }, 1000);
        }

        // Decrease quantity
        function decreaseQuantity(e) {
            const id = e.target.closest('.cart-item').dataset.id;
            const item = cart.find(item => item.id === id);
            
            if (item.quantity > 1) {
                item.quantity -= 1;
                updateCart();
            }
        }

        // Increase quantity
        function increaseQuantity(e) {
            const id = e.target.closest('.cart-item').dataset.id;
            const item = cart.find(item => item.id === id);
            
            item.quantity += 1;
            updateCart();
        }

        // Update quantity
        function updateQuantity(e) {
            const id = e.target.closest('.cart-item').dataset.id;
            const item = cart.find(item => item.id === id);
            const newQty = parseInt(e.target.value);
            
            if (newQty > 0) {
                item.quantity = newQty;
                updateCart();
            } else {
                e.target.value = item.quantity;
            }
        }

        // Remove item
        function removeItem(e) {
            const id = e.target.closest('.cart-item').dataset.id;
            cart = cart.filter(item => item.id !== id);
            updateCart();
        }

        // Clear cart
        function clearCart() {
            cart = [];
            updateCart();
        }

        // Checkout
        function checkout() {
            if (cart.length === 0) {
                alert('Your cart is empty!');
                return;
            }
            
            // Render order summary in modal
            const modalOrderItems = document.getElementById('modal-order-items');
            modalOrderItems.innerHTML = '';
            
            cart.forEach(item => {
                modalOrderItems.innerHTML += `
                    <div class="order-summary-item">
                        <span>${item.name} x${item.quantity}</span>
                        <span>$${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                `;
            });
            
            // Update subtotal and total
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            const deliveryFee = 2.99;
            const total = subtotal + deliveryFee;
            
            document.querySelector('.order-subtotal').textContent = `$${subtotal.toFixed(2)}`;
            document.querySelector('.order-total').textContent = `$${total.toFixed(2)}`;
            
            // Show checkout modal
            document.getElementById('checkoutModal').classList.add('active');
        }

        // Place order
        function placeOrder(e) {
            e.preventDefault();
            
            // Generate random order ID
            const orderId = Math.floor(1000 + Math.random() * 9000);
            document.getElementById('orderId').textContent = orderId;
            
            // Hide checkout modal, show confirmation
            document.getElementById('checkoutModal').classList.remove('active');
            document.getElementById('confirmationModal').classList.add('active');
            
            // Clear cart
            clearCart();
        }

        // Continue shopping
        function continueShopping() {
            document.getElementById('confirmationModal').classList.remove('active');
        }

        // Event listeners
        addToCartBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.dataset.id;
                const name = btn.dataset.name;
                const price = btn.dataset.price;
                const image = btn.dataset.image;
                
                addToCart(id, name, price, image);
            });
        });

        clearCartBtn.addEventListener('click', clearCart);
        checkoutBtn.addEventListener('click', checkout);
        
        document.querySelector('.modal-close').addEventListener('click', () => {
            document.getElementById('checkoutModal').classList.remove('active');
        });
        
        document.getElementById('checkoutForm').addEventListener('submit', placeOrder);
        document.getElementById('continueShopping').addEventListener('click', continueShopping);

        // Initialize cart
        updateCart();
    </script>
</body>
</html>